# This is a sample Python script.
from __future__ import print_function


# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


# Press the green button in the gutter to run the script.
# не добавляйте кода вне функции


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
with open("/Users/a18881415/Desktop/selenium_course/pyt/input.txt") as dna:
    dna_str = dna.readline()
print(dna_str)
result = ""
n = 0
accum = ""
sim = ""
for i in range(len(dna_str)-1):
    if dna_str[i].isdigit():
        if dna_str[i+1].isdigit():
            accum = accum + dna_str[i]
        else:
            if accum != "":
                n = int(accum + dna_str[i])
                result = result + sim * n
                accum = ""
            else:
                n = int(dna_str[i])
                result = result + sim * n
    else:
        sim = dna_str[i]
print(result)
with open("/Users/a18881415/Desktop/selenium_course/pyt/out.txt", "w") as out:
    out.write(result)
