russian_alpha = "абвгдежзийклмнопрстуфхцчшщъыьэюяабвгдежзийклмнопрстуфхцчшщъыьэюя"
big_russian_alpha = "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯАБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
english_alpha = 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz'
big_english_alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ'

def encript(step, text):
    result = ''
    for i in range(len(text)):
        if text[i] in russian_alpha:
            ind = russian_alpha.find(text[i])
            result += russian_alpha[(ind+step) % 32]
            continue
        elif text[i] in big_russian_alpha:
            ind = big_russian_alpha.find(text[i])
            result += big_russian_alpha[(ind+step) % 32]
            continue
        if text[i] in english_alpha:
            ind = english_alpha.find(text[i])
            result += english_alpha[(ind+step) % 26]
            continue
        elif text[i] in big_english_alpha:
            ind = big_english_alpha.find(text[i])
            result += big_english_alpha[(ind+step) % 26]
            continue
        else:
            result += text[i]
            continue
    print(result, end=' ')

def decript(step, text):
    encript(-step, text)

text = input().split()
for word in text:
    count = 0
    for i in word:
        if i in english_alpha or i in big_english_alpha:
            count += 1
    encript(count, word)
