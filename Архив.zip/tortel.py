count = int(input())
x, y = 0, 0
for i in range(count):
    vector, value = input().split()
    if vector == "север":
        y += int(value)
    elif vector == "восток":
        x += int(value)
    elif vector == "юг":
        y -= int(value)
    else:
        x -= int(value)
print(x, y)
