import operator
operators = {"plus": operator.add, "minus": operator.sub, "multiply": operator.mul, "divide": operator.floordiv}
a, oper, b = input().split()
print(operators[oper](int(a), int(b)))

