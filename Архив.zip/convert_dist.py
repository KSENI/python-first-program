all = input().split()
value = float(all[0])
units_1 = all[1]
units_2 = all[3]
info = {'mile': 1609, 'yard': 0.9144, 'foot': 0.3048, 'inch': 0.0254, 'km': 1000, 'm': 1, 'cm': 0.01, 'mm': 0.001}

in_m = value * info[units_1]
print("%.2e" % (in_m / info[units_2]))
