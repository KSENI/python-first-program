import requests
file = open("/Users/a18881415/Desktop/selenium_course/pyt/input2.txt", "wb")
r = requests.get('https://stepic.org/media/attachments/course67/3.6.2/237.txt')
file.write(r.content)
file.close()

count = 0
file = open("/Users/a18881415/Desktop/selenium_course/pyt/input2.txt", "r")
for line in file:
    count += 1
print(count)

