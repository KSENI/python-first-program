import random
digits = '0123456789'
lowercase_letters = 'abcdefghijklmnopqrstuvwxyz'
uppercase_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
punctuation = '!#$%&*+-=?@^_'
chars = digits + lowercase_letters + uppercase_letters + punctuation

def generate_password(length, chars):
    res = ''
    for i in range(length):
        a = random.randint(1, len(chars))
        res += chars[a:a+1]
    print(res)

n = int(input('Количество паролей:'))
l = int(input('Длинна одного пароля:'))
for i in range(n):
    generate_password(l, chars)
