def get_int(start_message, error_message, end_message):
    print(start_message)
    while True:
        n = input()
        try:
            int(n)
            print(end_message)
            break
        except ValueError:
            print(error_message)
            continue
    return int(n)

x = get_int('Input int number:', 'Wrong value. Input int number:', 'Thank you.')
print(x)
