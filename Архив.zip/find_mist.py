count_words = int(input())
words = []
for i in range(count_words):
    words.append(input().lower())
count_str = int(input())
strings = []
for i in range(count_str):
    strings.extend(input().lower().split())
errors = []
for i in strings:
    if i not in words:
        if i not in errors:
            errors.append(i)
print("\n".join(errors))
