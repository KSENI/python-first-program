# This is a sample Python script.
from __future__ import print_function


# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


# Press the green button in the gutter to run the script.
# не добавляйте кода вне функции


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
frequency = {}
# save frequencies of word
with open("/Users/a18881415/Desktop/selenium_course/pyt/input.txt") as inf:
    for line in inf:
        line = line.strip().lower().split()
        for i in line:
            if i in frequency:
                frequency[i] += 1
            else:
                frequency[i] = 1
# find maximum frequency
maximum = 0
for key, value in frequency.items():
    if value > maximum:
        maximum = value
# find keys for maximum frequencies
maximum_keys = []

for key in frequency:
    if frequency[key] == maximum:
        maximum_keys.append(key)
print(maximum_keys)
key = sorted(maximum_keys)[0]
print(key, " ", frequency[key])

