def revert_rom_to_arabic(text):
    result = 0
    if (len(text)) == 1:  # in case one-length input
        result += rom_2[text[0]]
        print(result)
        return result
    while len(text) >= 2:
        if text[i-1] + text[i] in rom_1:
            result += rom_1[text[i-1] + text[i]]
            text = text[i+1:]
        else:
            result += rom_2[text[i-1]]
            text = text[i:]
            if i + 1 >= len(text):
                if i + 1 == len(text):
                    if text[i-1] + text[i] in rom_1:
                        result += rom_1[text[i - 1] + text[i]]
                        break
                    else:
                        result += rom_2[text[i]]
                        result += rom_2[text[i - 1]]
                        text = text[i+1:]
                        break
                else:
                    result += rom_2[text[i - 1]]
                    text = text[i:]
                    break
    if len(text) == 1:
        result += rom_2[text[0]]
    print(result)
    return result


rom_1 = {"IV":4, "IX": 9, "XL": 40, "XC": 90, "CD": 400, "CM": 900, }
rom_2 = {"I": 1, "V":5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
text = input()
# text = "IVM"
i = 1
revert_rom_to_arabic(text)

# assert revert_rom_to_arabic("IX") == 9, "не равно"
# assert revert_rom_to_arabic("I") == 1, "не равно"
# assert revert_rom_to_arabic("X") == 10, "не равно"
# assert revert_rom_to_arabic("MCMLXXXIV") == 1984, "не равно"
# assert revert_rom_to_arabic("III") == 3, "не равно"
# assert revert_rom_to_arabic("MCMLIV") == 1954, "не равно"
# assert revert_rom_to_arabic("IXIXIX") == 27, "не равно"
# assert revert_rom_to_arabic("MMMIIIII") == 3005, "не равно"
# assert revert_rom_to_arabic("IVM") == 1004, "не равно"
# assert revert_rom_to_arabic("MIV") == 1004, "не равно"
# assert revert_rom_to_arabic("MMMCMXCIX") == 3999, "не равно"
# assert revert_rom_to_arabic("MM") == 2000, "не равно"
# assert revert_rom_to_arabic("IX") == 9, "не равно"




