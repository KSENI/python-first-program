for a in range(25, 32):
    print(a)
    for b in range(32, 96):
        for c in range(96, 128):
            for d in range(128, 150):
                for e in range(1, 150):
                    if a ** 5 + b ** 5 + c ** 5 + d ** 5 == e ** 5:
                        print(a, b, c, d, e)
                        break
