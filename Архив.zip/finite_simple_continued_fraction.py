a, b = (int(i) for i in input().split("/"))
number_1 = a // b
print(number_1)
mod_1 = a - number_1 * b
number_2 = b // mod_1
print(number_2)
print(mod_1)
# mod_2 = b - number_2 * mod_1
# first_3 = b // mod_2
# print(mod_2)
# print(first_3)

