count_words = int(input())
all_texts = []
for i in range(count_words):
    cur = input()
    if cur not in all_texts:
        all_texts.append(cur)
all_search_words = []
count_search_words = int(input())
for i in range(count_search_words):
    cur = input()
    if cur not in all_texts:
        all_search_words.append(cur)
for text in all_texts:
    is_all_search = True
    for search_word in all_search_words:
        if search_word.lower() not in text.lower():
            is_all_search = False
    if is_all_search:
        print(text)
        is_all_search = True


