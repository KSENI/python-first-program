import requests

file = open("/Users/a18881415/Desktop/selenium_course/pyt/input2.txt", "wb")
r = requests.get('https://stepic.org/media/attachments/course67/3.6.3/699991.txt')
file.write(r.content)
file.close()

file = open("/Users/a18881415/Desktop/selenium_course/pyt/input2.txt", "r")
next1 = file.readline().strip()
file.close()
while True:
    file = open("/Users/a18881415/Desktop/selenium_course/pyt/input2.txt", "wb")
    url = 'https://stepic.org/media/attachments/course67/3.6.3/' + next1
    r = requests.get(url)
    file.write(r.content)
    file.close()
    file = open("/Users/a18881415/Desktop/selenium_course/pyt/input2.txt", "r")
    next1 = file.readline()
    print(next1)
    if "We" in next1:
        print(next1)
        break
