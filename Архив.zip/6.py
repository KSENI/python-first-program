name = input()
all = []
res = []
with open(name) as file:
    for line in file:
        all.append(line.strip())
for i in range(len(all)):
    if all[i].startswith('def '):
        if not all[i-1].startswith('#'):
            ind_start = 4
            ind_end = all[i].index('(')
            res.append(all[i][ind_start:ind_end])
if len(res) > 0:
    print(*res, sep='\n')
else:
    print('Best Programming Team')
