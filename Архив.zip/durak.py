card_1, card_2 = input().split()
suit_1 = card_1[-1:]
suit_2 = card_2[-1:]
value_1 = card_1[:-1]
value_2 = card_2[:-1]
trump = input()
weights = {"6": 6, "7": 7, "8": 8, "9": 9, "10": 10, "J": 11, "Q": 12, "K": 13, "A": 14}
is_card_1_more_than_card_2 = weights[value_1] > weights[value_2]
is_card_2_more_than_card_1 = weights[value_1] < weights[value_2]
is_card_1_tramp = suit_1 == trump
is_card_2_tramp = suit_2 == trump
result = ""

# one card trump
if is_card_1_tramp and not is_card_2_tramp:
    result = "First"
if is_card_2_tramp and not is_card_1_tramp:
    result = "Second"

# two cards are trump or two cards are not trump
if ((is_card_1_tramp and is_card_2_tramp) or (not is_card_1_tramp and not is_card_2_tramp)) and (suit_2 == suit_1):
    if is_card_1_more_than_card_2:
        result = "First"
    elif is_card_2_more_than_card_1:
        result = "Second"
    else:
        result = "Error"
if result == "":
    result = "Error"
print(result)

