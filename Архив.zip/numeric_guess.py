import random
def ask_nositive_int():
    answer = input()
    while not is_valid(answer):
        answer = input('Введите число от 1 до 100: \n')
    return int(answer)

def is_valid(text):
    if text.isdigit():
        if 1 <= int(text) <= 100:
            return True
    return False

def text_number_of_attempts(n):
    special = [10, 11, 12, 13, 14]
    if (n % 10 == 2 or n % 10 == 3 or n % 4 == 4) and n not in special:
        return 'попытки'
    elif n % 10 == 1 and n not  in special:
        return 'попытка'
    else:
        return 'попыток'

def game():
    print('Добро пожаловать в числовую угадайку'
      '\nЧисло?')
    number = random.randint(1, 100)
    answer = ask_nositive_int()
    count = 1
    while answer != number:
        if answer > number:
            print('Слишком много, попробуйте еще раз')
        elif answer < number:
            print('Слишком мало, попробуйте еще раз')
        answer = ask_nositive_int()
        count += 1
    print(f'Вы угадали за {count} {text_number_of_attempts(count)}, поздравляем!')
    print('Спасибо, что играли в числовую угадайку.')
    yes = input('Если хотите сыграть еще введите Y \n')
    if yes == 'Y':
        game()

game()


