import unittest
from rom import Rom


class TestRom(unittest.TestCase):
    def setUp(self):
        self.calculator = Rom()

    def test_add(self):
        self.assertEqual(self.calculator.revert_rom_to_arabic("IX"), 9)
