results = {}
# key class_room, value: [sum of height, count of pupils]
with open("/Users/a18881415/Desktop/selenium_course/pyt/input.txt") as heights:
    for line in heights:
        all = line.split()
        class_room = int(all[0])
        height = float(all[2])
        if class_room not in results:
            results[class_room] = [height, 1]
        else:
            results[class_room][0] += height
            results[class_room][1] += 1
for i in range(11 + 1):
    if i in results:
        print(i, results[i][0]/results[i][1])
    else:
        print(i, "-")

