rom = {1000: "M", 900: "CM", 500: "D", 400: "CD", 100: "C", 90: "XC", 50: "L", 40: "XL",
       10: "X", 9: "IX", 5: "V", 4: "IV", 1: "I"}
arabic = int(input())
result = ""
for key, value in sorted(rom.items(), reverse=True):
    if arabic // key > 0:
        n = arabic // key
        for i in range(n):
            result += value
            arabic -= key
print(result)

