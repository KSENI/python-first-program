text = input()
code = input()
for_encrypt = input()
for_decrypt = input()
crypt1 = {}
crypt2 = {}
for i in range(len(text)):
   crypt1[text[i]] = code[i]
   crypt2[code[i]] = text[i]
for i in range(len(for_encrypt)):
    print(crypt1[for_encrypt[i]], end="")
print()
for i in range(len(for_decrypt)):
    print(crypt2[for_decrypt[i]], end="")
