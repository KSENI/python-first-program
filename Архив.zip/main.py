students = {}
count = 0
middle_math = 0
middle_physics = 0
middle_russian = 0
with open("/Users/a18881415/Desktop/selenium_course/pyt/input.txt") as inf:
    for line in inf:
        last_name, math, physics, russian = line.strip().split(";")
        middle_stud = (int(math) + int(physics) + int(russian)) / 3
        students[last_name] = [int(math), int(physics), int(russian), middle_stud]

        count += 1
        middle_math += int(math)
        middle_physics += int(physics)
        middle_russian += int(russian)
middle_math /= count
middle_russian /= count
middle_physics /= count
print(students)
print(middle_math, middle_physics, middle_russian)
with open("/Users/a18881415/Desktop/selenium_course/pyt/out.txt", "w") as out:
    for key, value in students.items():
        out.write(str(students[key][3]) + "\n")
    out.write(str(middle_math) + " " + str(middle_physics) + " " + str(middle_russian))

