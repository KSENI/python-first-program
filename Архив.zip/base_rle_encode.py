def split_encode_series(text):
    current_count = 0
    items = []
    item_counts = []
    if len(text) == 1:
        print(text)
    else:
        for i in range(0, len(text)-1):
            current = text[i]
            if current == text[i+1]:
                current_count += 1
            else:
                items.append(current)
                item_counts.append(current_count + 1)
                current_count = 0
        try:
            if text[len(text)-1] == items[len(items) - 1]:
                item_counts[len(item_counts)] += 1
            else:
                items.append(text[len(text)-1])
                item_counts.append(current_count + 1)
        except IndexError:
            items.append(text[len(text)-1])
            item_counts.append(current_count + 1)
    for i in range(len(items)):
        if item_counts[i] > 1:
            print(item_counts[i], end="")
        print(items[i], end="")

text = input()
split_encode_series(text)

