n = int(input())
print(str(bin(n))[2:])
print(str(oct(n))[2:])
print(str(hex(n))[2:])
