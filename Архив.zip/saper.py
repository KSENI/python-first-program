n, m = (int(i) for i in input().split())
field = [[0 for j in range(m)] for i in range(n)]
for i in range(n):
    current = input()
    for j in range(len(current)):
        if current[j] == "*":
            field[i][j] = -1

for i in range(n):
    for j in range(m):
        if field[i][j] == 0:
            for di in range(-1, 2):
                for dj in range(-1, 2):
                    ai = i + di
                    aj = j + dj
                    if 0 <= ai < n and 0 <= aj < m and field[ai][aj] == -1:
                        field[i][j] += 1
for i in range(n):
    for j in range(m):
        if field[i][j] == -1:
            print("*", end="")
        else:
            print(field[i][j], end="")
    print()

