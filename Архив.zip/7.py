num = int('1000001', 2)
print(num)
