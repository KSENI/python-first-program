n = int(input())
results = {}
draw_price = 1
win_price = 3
# 0 - all, 1 - win, 2 - draw, 3 - fail
for i in range(n):
    team_1, team_1_goals, team_2, team_2_goals = input().strip().split(";")
    if team_1 not in results:
        results[team_1] = [0, 0, 0, 0, 0]
    if team_2 not in results:
        results[team_2] = [0, 0, 0, 0, 0]
    if int(team_1_goals) > int(team_2_goals):
        results[team_1][0] += 1
        results[team_2][0] += 1
        results[team_1][1] += 1
        results[team_2][3] += 1
    elif int(team_2_goals) > int(team_1_goals):
        results[team_2][0] += 1
        results[team_1][0] += 1
        results[team_2][1] += 1
        results[team_1][3] += 1
    else:
        results[team_2][2] += 1
        results[team_1][2] += 1
        results[team_2][0] += 1
        results[team_1][0] += 1
for key, value in results.items():
   score = results[key][1] * win_price + results[key][2] * draw_price
   results[key][4] = score
   print(f"{key}:{results[key][0]} {results[key][1]} {results[key][2]} {results[key][3]} {results[key][4]}")

